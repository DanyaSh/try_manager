# try_manager
Manager for telegram bot on aiogram to use try except request without big construction in your code.
